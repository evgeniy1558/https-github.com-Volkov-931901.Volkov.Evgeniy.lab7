'use strict';

class Figure {
    size = getRandom(60, 300);
    borderColor = '#000000';
    borderWidth = 2;
    position = 'absolute';
    x = getRandom(10, 1300);
    y = getRandom(10, 900);

    constructor(backgroundColor) {
        this.backgroundColor = backgroundColor;
    }

    _addShape(shape) {
        let svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
        svg.setAttribute('viewBox', '0 0 ' + this.size + ' ' + this.size);
        svg.setAttribute('width', this.size);
        svg.setAttribute('height', this.size);
        svg.dataset.shape = this.constructor.name.toLowerCase();

        svg.style.position = this.position;
        svg.style.left = this.x + 'px';
        svg.style.top = this.y + 'px';

        svg.appendChild(shape);

        return svg;
    }
}

class Square extends Figure {
    getSvg() {
        let shape = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
        shape.setAttribute('x', this.borderWidth);
        shape.setAttribute('y', this.borderWidth);
        shape.setAttribute('width', this.size - 2 * this.borderWidth);
        shape.setAttribute('height', this.size - 2 * this.borderWidth);
        shape.setAttribute('fill', this.backgroundColor);
        shape.setAttribute('opacity', '0.7');
        shape.setAttribute('stroke', this.borderColor);
        shape.setAttribute('stroke-width', this.borderWidth);

        return super._addShape(shape);
    }
}

class Triangle extends Figure {
    getSvg() {
        let shape = document.createElementNS('http://www.w3.org/2000/svg', 'polygon');
        shape.setAttribute('points', `${this.borderWidth} ${this.size - this.borderWidth}, ${this.size - this.borderWidth} ${this.size - this.borderWidth}, ${this.size / 2} ${this.borderWidth}`);
        shape.setAttribute('fill', this.backgroundColor);
        shape.setAttribute('opacity', '0.7');
        shape.setAttribute('stroke', this.borderColor);
        shape.setAttribute('stroke-width', this.borderWidth);

        return super._addShape(shape);
    }
}

class Circle extends Figure {
    getSvg() {
        let shape = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
        shape.setAttribute('cx', this.size / 2);
        shape.setAttribute('cy', this.size / 2);
        shape.setAttribute('r', (this.size - 2 * this.borderWidth) / 2);
        shape.setAttribute('fill', this.backgroundColor);
        shape.setAttribute('opacity', '0.7');
        shape.setAttribute('stroke', this.borderColor);
        shape.setAttribute('stroke-width', this.borderWidth);

        return super._addShape(shape);
    }
}

function generateKit(count, classFigure, color) {
    var kit = [];

    for (let i = 0; i < count; i++) {
        kit.push(new classFigure(color));
    }

    return kit;
}

function renderKit(kit, parentElement) {
    kit.forEach(element => {
        parentElement.appendChild(element.getSvg());
    });
}

function getRandom(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

const FIGURE_COLOR = {
    square: '#ff6347',
    triangle: '#6495ed',
    circle: '#90ee90'
}

let btnSquare = document.getElementById('btnSquare'),
    btnTriangle = document.getElementById('btnTriangle'),
    btnCircle = document.getElementById('btnCircle'),
    container = document.getElementById('container'),
    fieldCount = document.getElementById('fieldCount'),
    containerElement = document.getElementById('container');

let selectedFigure;

btnSquare.addEventListener('click', function () {
    let countSquare = Number(fieldCount.value);
    let squareKit = generateKit(countSquare, Square, FIGURE_COLOR.square);
    renderKit(squareKit, container);
});

btnTriangle.addEventListener('click', function () {
    let countTriangle = Number(fieldCount.value);
    let triangleKit = generateKit(countTriangle, Triangle, FIGURE_COLOR.triangle);
    renderKit(triangleKit, container);
});

btnCircle.addEventListener('click', function () {
    let countCircle = Number(fieldCount.value);
    let circleKit = generateKit(countCircle, Circle, FIGURE_COLOR.circle);
    renderKit(circleKit, container);
});

container.addEventListener('dblclick', function (e) {
    if (e.target.parentElement.hasAttribute('data-shape')) {
        this.removeChild(e.target.parentElement);
    }
});

container.addEventListener('click', function (e) {
    if (e.target.parentElement.hasAttribute('data-shape') && e.target !== selectedFigure) {
        if (selectedFigure) {
            selectedFigure.setAttribute('fill', FIGURE_COLOR[selectedFigure.parentElement.dataset.shape]);
        }
        selectedFigure = e.target;
        selectedFigure.setAttribute('fill', 'yellow');
    }
});